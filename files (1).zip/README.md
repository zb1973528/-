# Mini-Agent：从零实现的最小可用 Agent

不依赖任何 Agent 框架（无 langgraph / openhands 等），核心 Runtime 全部自行实现。
接入**硅基流动（SiliconFlow）**的 OpenAI 兼容接口作为真实 LLM。

---

## 一、运行方式

### 1. 安装
```bash
pip install -r requirements.txt      # 只有 requests；测试无需任何依赖
```

### 2. 配置 API Key
```bash
cp .env.example .env
# 编辑 .env，填入 SILICONFLOW_API_KEY=sk-xxxx
# 或直接： export SILICONFLOW_API_KEY=sk-xxxx
```

### 3. 交互模式（真实 API）
```bash
python main.py
```
交互内命令：
- `/new <id>` / `/switch <id>`：新建或切换会话（演示多窗口隔离）
- `/sessions`：列出所有会话
- `/todos`：查看当前会话待办
- `/quit`：退出

### 4. 演示模式（真实 API，自动跑隔离性场景）
```bash
python main.py --demo
```
会自动演示：窗口1「查天气+记待办」、窗口2「写周报+记待办」、回窗口1验证待办互不干扰、以及带工具的追问。

### 5. 测试（离线、确定性，不消耗 API）
```bash
python tests/test_agent.py
```
覆盖：工具调用、纯对话/带工具追问、session 隔离、工具报错自愈、解析失败自愈、压缩后连贯、最大步数兜底。全部 17 条断言通过。

执行轨迹会实时打印，并落盘到 `logs/<session_id>.log`。

---

## 二、系统设计

### 目录结构
```
trace.py       执行轨迹（thought/action/observation 逐步落痕，终端+文件）
tools.py       Tool 基类 + ToolRegistry + 4 个工具（calculator/search/weather/todo）
session.py     Session + SessionManager（多窗口隔离的物理基础）
protocol.py    ReAct JSON 协议：拼 system prompt + 解析 LLM 输出
context.py     上下文组装 + 压缩（滚动摘要）
llm.py         SiliconFlowLLM（真实）+ ScriptedLLM（测试）
agent.py       Agent Runtime 主循环
main.py        CLI 入口
tests/         离线测试
```

### 主循环（agent.py）
```
接收用户输入 → 入历史 → (若过长)压缩
  └─ 循环(最多 MAX_STEPS 步)：
       组装 context → 调 LLM → 解析
         ├─ 解析失败 → 把错误当 observation 反馈，模型自愈（有独立重试预算）
         ├─ action  → 执行工具(异常也转 observation) → 继续循环
         └─ final   → 写回历史，返回用户
  └─ 超步数 → 优雅兜底
```

### 工具注册机制（tools.py）
每个工具 = `name` + `description` + `parameters`(JSON Schema) + `run(args, session)`。
`ToolRegistry.schemas()` 把所有工具的结构化描述注入 system prompt，LLM 据此**自主决策**调用哪个工具、传什么参数。`run` 传入 `session`，让 `todo` 这类工具能持有**会话级状态**。

### 为什么用 Prompt+JSON 协议而非原生 function calling？
题目要求"自行实现 LLM 输出的解析逻辑，提取思考过程/工具调用/最终答案"。
原生 function calling 会把解析藏进 SDK，且不一定给出显式 thought。
本项目让模型每步只输出一个 JSON：
```json
{"thought":"...", "action":{"tool":"...","args":{...}}}   // 或
{"thought":"...", "final_answer":"..."}
```
`protocol.parse_output` 负责鲁棒解析（容忍代码围栏/前后多余文字，做括号平衡扫描）。
代价是对模型指令遵循有要求 → 用"解析失败自愈"兜住。
（这个取舍正好对应架构设计题的模块五。）

### 异常处理
- 工具报错：`try/except` 后把 `ERROR: ...` 作为 observation 反馈，模型可换参/换招，而非整体崩溃。
- 解析失败：反馈协议错误让模型重出，有 `MAX_PARSE_RETRIES` 预算。
- LLM 调用失败：客户端内退避重试；仍失败则优雅兜底话术。
- 死循环：`MAX_STEPS` 上限强制结束。

---

## 三、Memory：召回时机与放置方式（重点）

### 放什么进 context
- **system**：角色 + 全部工具 schema + 输出协议 + **早期摘要**（若有）。
- **最近若干轮原始消息**：`user`（用户输入）/ `assistant`（模型每步原始输出，含 thought+action/final）/ `observation`（工具结果）。三类都保留，因为追问既可能针对用户说过的话，也可能针对工具查到的结果或模型的中间推理。
- **大结果截断**：单条工具返回超过 `MAX_OBS_CHARS`(默认1200) 先截断再入历史，避免单条 observation 撑爆窗口。

### 分层记忆
1. **短期**：最近 `KEEP_RECENT`(默认6) 条**原文**，保证追问连贯、细节无损。
2. **长期**：更早历史被压缩为一份**滚动摘要**（summary），保留关键事实、用户偏好、决策、待办、未完成目标，丢弃寒暄。
3. **会话级结构化状态**：`session.todos` 这类不进 prompt、但由工具读写的持久状态。

### 召回时机（何时把记忆放回 context）
- **每一轮对话开始时**调用 `context.maybe_compress`：当历史规模 `approx_size()` 超过 `COMPRESS_CHAR_BUDGET`(默认3500字符) 就触发压缩，把"最老一段 + 已有摘要"交给 LLM 融合成新摘要，替换原文，仅保留最近 K 条。
- **摘要始终注入 system prompt** 的固定位置（工具协议之后），因此每次生成都会"召回"这份长期记忆——无需显式检索，摘要即常驻上下文。
- 短期原文天然在 messages 里被"召回"，支持精确追问。

> 说明：这是**基础压缩**（滚动摘要 buffer）。更复杂的方案（向量检索式记忆、按话题分片召回、重要性打分等）不在本最小实现范围，但架构设计题的"Memory / Context 压缩"模块里有展开讨论。

---

## 四、关键参数（可调）
| 参数 | 位置 | 默认 | 含义 |
|---|---|---|---|
| `MAX_STEPS` | agent.py | 8 | 单轮最多工具步数 |
| `MAX_PARSE_RETRIES` | agent.py | 2 | 解析失败自愈次数 |
| `MAX_OBS_CHARS` | context.py | 1200 | 单条工具结果入历史上限 |
| `COMPRESS_CHAR_BUDGET` | context.py | 3500 | 触发压缩的历史规模 |
| `KEEP_RECENT` | context.py | 6 | 压缩时保留的最近原文条数 |
