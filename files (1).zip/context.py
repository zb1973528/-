"""
context.py — 上下文管理：组装 + 压缩

两个核心问题：
(A) 放什么进 context？
    - system：角色 + 工具 schema + 输出协议 + 早期摘要
    - 最近若干轮的原始消息：user / assistant(含thought+action) / observation
    - 工具原始返回若过大会先截断再入历史（见 MAX_OBS_CHARS），避免单条 observation 撑爆
(B) 超长了怎么办？（基础压缩，不做复杂压缩）
    - 当历史规模超过 COMPRESS_CHAR_BUDGET，把"最老的一段"交给 LLM 生成/合并成滚动摘要，
      用摘要替换这些原始消息；最近 KEEP_RECENT 条保留原文，保证追问的连贯性。
    - 召回时机：每轮开始时检查是否需要压缩；摘要始终注入 system，作为长期记忆被"召回"。
"""

# ------- 可调参数 -------
MAX_OBS_CHARS = 1200        # 单条工具结果入历史时的最大字符数
COMPRESS_CHAR_BUDGET = 3500 # 历史规模超过此值触发压缩（字符数代理 token）
KEEP_RECENT = 6             # 压缩时保留最近多少条原始消息不动


def clip_observation(text: str) -> str:
    if len(text) <= MAX_OBS_CHARS:
        return text
    return text[:MAX_OBS_CHARS] + f"\n...[结果过长，已截断，原长 {len(text)} 字符]"


def build_messages(session, system_prompt: str) -> list[dict]:
    """
    把内部消息(role: user/assistant/observation)映射为 OpenAI 兼容的 chat messages。
    observation 没有原生角色，这里统一映射为 user，并加 "工具返回：" 前缀，让模型能区分。
    """
    msgs = [{"role": "system", "content": system_prompt}]
    for m in session.messages:
        role = m["role"]
        if role == "assistant":
            msgs.append({"role": "assistant", "content": m["content"]})
        elif role == "observation":
            msgs.append({"role": "user", "content": f"工具返回：{m['content']}"})
        else:  # user
            msgs.append({"role": "user", "content": m["content"]})
    return msgs


def maybe_compress(session, llm) -> bool:
    """
    若历史过长则压缩。返回是否发生了压缩。
    压缩策略：保留最近 KEEP_RECENT 条原文，其余 + 现有摘要一起交给 LLM 重写为新的滚动摘要。
    """
    if session.approx_size() <= COMPRESS_CHAR_BUDGET:
        return False
    if len(session.messages) <= KEEP_RECENT + 2:
        return False  # 太短没必要（可能是单条巨大 observation，已截断处理）

    to_compress = session.messages[:-KEEP_RECENT]
    recent = session.messages[-KEEP_RECENT:]

    # 把待压缩内容拼成文本
    dialog_text = []
    for m in to_compress:
        tag = {"user": "用户", "assistant": "助手", "observation": "工具"}.get(m["role"], m["role"])
        dialog_text.append(f"{tag}: {m['content']}")
    dialog_text = "\n".join(dialog_text)

    prompt = [
        {
            "role": "system",
            "content": (
                "你是对话压缩器。请把【已有摘要】和【新增对话】融合成一份**新的滚动摘要**。"
                "要求：保留关键事实、用户偏好、已做的决策、待办、未完成的目标；"
                "去掉寒暄和冗余；用第三人称、条目化、简洁。只输出摘要正文。"
            ),
        },
        {
            "role": "user",
            "content": f"【已有摘要】\n{session.summary or '（无）'}\n\n【新增对话】\n{dialog_text}",
        },
    ]
    try:
        new_summary = llm.complete(prompt).strip()
    except Exception as e:
        session.trace.error(f"压缩失败，跳过本次压缩: {e}")
        return False

    session.summary = new_summary
    session.messages = recent
    session.trace.system(f"已压缩 {len(to_compress)} 条历史为摘要，保留最近 {len(recent)} 条。")
    return True
