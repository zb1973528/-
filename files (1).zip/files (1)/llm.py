"""
llm.py — LLM 客户端

- SiliconFlowLLM：接硅基流动（OpenAI 兼容 /chat/completions）。真实调用。
- ScriptedLLM：测试用。可传入固定回复队列或一个 callback(messages)->str，
  让测试完全离线、确定性，不消耗 API。

两者都实现统一接口：complete(messages: list[dict]) -> str
"""
import os
import time


class LLMError(Exception):
    pass


class SiliconFlowLLM:
    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
        base_url: str | None = None,
        temperature: float = 0.2,
        timeout: int = 60,
        max_retries: int = 2,
    ):
        self.api_key = api_key or os.getenv("SILICONFLOW_API_KEY")
        self.model = model or os.getenv("MINI_AGENT_MODEL", "Qwen/Qwen2.5-72B-Instruct")
        self.base_url = (base_url or os.getenv(
            "MINI_AGENT_BASE_URL", "https://api.siliconflow.cn/v1"
        )).rstrip("/")
        self.temperature = temperature
        self.timeout = timeout
        self.max_retries = max_retries
        if not self.api_key:
            raise LLMError("未设置 SILICONFLOW_API_KEY 环境变量")

    def complete(self, messages: list[dict]) -> str:
        import requests  # 延迟导入：测试用 ScriptedLLM 时无需安装 requests

        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": self.temperature,
        }

        last_err = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = requests.post(url, headers=headers, json=payload, timeout=self.timeout)
                if resp.status_code != 200:
                    raise LLMError(f"HTTP {resp.status_code}: {resp.text[:300]}")
                data = resp.json()
                return data["choices"][0]["message"]["content"] or ""
            except Exception as e:
                last_err = e
                if attempt < self.max_retries:
                    time.sleep(1.5 * (attempt + 1))  # 简单退避重试
                    continue
                raise LLMError(f"LLM 调用失败（已重试 {self.max_retries} 次）: {e}") from e
        raise LLMError(str(last_err))


class ScriptedLLM:
    """
    测试专用。两种模式：
      - responses: 一个字符串列表，按调用顺序 FIFO 弹出。
      - fn: 一个 callable(messages)->str，可根据当前 messages 动态决定返回，
            便于写"看到工具结果后再给最终答案"这类分支逻辑。
    """
    def __init__(self, responses: list[str] | None = None, fn=None):
        self._responses = list(responses or [])
        self._fn = fn
        self.calls: list[list[dict]] = []  # 记录每次收到的 messages，供断言

    def complete(self, messages: list[dict]) -> str:
        self.calls.append(messages)
        if self._fn is not None:
            return self._fn(messages)
        if not self._responses:
            raise LLMError("ScriptedLLM 脚本已耗尽")
        return self._responses.pop(0)
