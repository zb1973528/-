"""
main.py — 命令行入口

用法：
  1) 交互模式（接真实硅基流动 API）：
       export SILICONFLOW_API_KEY=sk-xxxx
       python main.py
     交互内命令：
       /new <id>       新建并切到某个 session
       /switch <id>    切换到已有 session
       /sessions       列出所有 session
       /todos          查看当前 session 的待办
       /quit           退出

  2) 演示模式（自动跑"窗口1查天气记待办 / 窗口2写周报记待办"的隔离性场景，需真实 API）：
       python main.py --demo
"""
import os
import sys

from llm import SiliconFlowLLM
from tools import build_default_registry
from session import SessionManager
from agent import Agent


def _load_dotenv():
    """极简 .env 读取，避免额外依赖。"""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(path):
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def build_agent():
    llm = SiliconFlowLLM()
    registry = build_default_registry()
    return Agent(llm, registry)


def run_demo():
    """演示两个独立窗口互不干扰 + 追问。"""
    agent = build_agent()
    mgr = SessionManager()

    print("\n=== 窗口1 (session=win1)：查天气 + 记待办 ===")
    s1 = mgr.get_or_create("win1", user_id="A")
    print("助手>", agent.chat(s1, "帮我查一下北京今天的天气，然后把'带伞'加到待办里"))

    print("\n=== 窗口2 (session=win2)：写周报 + 记待办 ===")
    s2 = mgr.get_or_create("win2", user_id="A")
    print("助手>", agent.chat(s2, "帮我把'周五提交周报'加到待办，再列出我的待办"))

    print("\n=== 回到窗口1 追问：验证隔离性（win1 不该看到 win2 的待办）===")
    print("助手>", agent.chat(s1, "我现在的待办有哪些？"))

    print("\n=== 窗口1 带工具的追问 ===")
    print("助手>", agent.chat(s1, "顺便算一下 128 * 7 + 30 是多少"))


def run_interactive():
    agent = build_agent()
    mgr = SessionManager()
    current = mgr.get_or_create("default", user_id="A")
    print("Mini-Agent 已启动（输入 /quit 退出，/sessions 查看会话）。当前会话: default")

    while True:
        try:
            text = input(f"\n[{current.session_id}] 你> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n再见。")
            break
        if not text:
            continue

        if text.startswith("/"):
            parts = text.split()
            cmd = parts[0]
            if cmd == "/quit":
                print("再见。")
                break
            elif cmd == "/sessions":
                print("会话列表:", mgr.list_ids())
            elif cmd in ("/new", "/switch") and len(parts) >= 2:
                current = mgr.get_or_create(parts[1], user_id="A")
                print(f"当前会话切换为: {current.session_id}")
            elif cmd == "/todos":
                for i, t in enumerate(current.todos):
                    print(f"  {i+1}. [{'x' if t['done'] else ' '}] {t['content']}")
                if not current.todos:
                    print("  （空）")
            else:
                print("未知命令。可用: /new <id> /switch <id> /sessions /todos /quit")
            continue

        answer = agent.chat(current, text)
        print("助手>", answer)


if __name__ == "__main__":
    _load_dotenv()
    if "--demo" in sys.argv:
        run_demo()
    else:
        run_interactive()
