"""
session.py — 会话管理

需求场景：
  用户A 窗口1：查天气、记待办
  用户A 窗口2：写周报、记待办
两个窗口是两个 **独立 session**：各自持有自己的消息历史、摘要、待办，互不干扰，
可以随时切回任意一个继续聊。

实现关键：不要把历史存成全局单例。SessionManager 用 session_id 索引，
每个 Session 自带独立状态。
"""
import time
from trace import Trace


class Session:
    def __init__(self, session_id: str, user_id: str = "anonymous", to_console=True):
        self.session_id = session_id
        self.user_id = user_id
        self.created_at = time.time()

        # 原始对话/推理历史。每条 message 结构：{"role": ..., "content": ...}
        # role ∈ {user, assistant, observation}
        #   user        —— 用户输入
        #   assistant   —— 模型每一步的原始输出(含 thought + action/final 的 JSON)
        #   observation —— 工具执行结果（喂回给模型）
        self.messages: list[dict] = []

        # 运行时压缩产生的"滚动摘要"，代表更早历史的浓缩。
        self.summary: str = ""

        # 会话级待办存储（TodoTool 读写它）——隔离性的体现之一
        self.todos: list[dict] = []

        # 独立的执行轨迹
        self.trace = Trace(session_id, to_console=to_console)

    def add(self, role: str, content: str):
        self.messages.append({"role": role, "content": content})

    def turn_count(self) -> int:
        """用户发起的轮数（用于最大轮次/展示）。"""
        return sum(1 for m in self.messages if m["role"] == "user")

    def approx_size(self) -> int:
        """粗略估算历史规模（字符数）。中文场景下 1 字符≈1 token 量级，作为压缩阈值代理。"""
        return sum(len(m["content"]) for m in self.messages) + len(self.summary)


class SessionManager:
    def __init__(self, to_console=True):
        self._sessions: dict[str, Session] = {}
        self._to_console = to_console

    def get_or_create(self, session_id: str, user_id: str = "anonymous") -> Session:
        if session_id not in self._sessions:
            self._sessions[session_id] = Session(
                session_id, user_id, to_console=self._to_console
            )
        return self._sessions[session_id]

    def exists(self, session_id: str) -> bool:
        return session_id in self._sessions

    def list_ids(self) -> list[str]:
        return list(self._sessions.keys())
