"""
protocol.py — LLM 交互协议（Prompt 构造 + 输出解析）

设计选择：这里用「Prompt 注入 schema + 让模型输出结构化 JSON」的 ReAct 方案，
而不是依赖各家原生 function_calling。原因：
  1. 题目明确要求"自行实现 LLM 输出的解析逻辑，提取思考过程/工具调用/最终答案"，
     原生 function calling 会把解析藏进 SDK，无法体现"从零实现"。
  2. 能稳定拿到显式的 thought（思考过程），原生 tool_call 不一定给。
权衡：Prompt 方案对模型的指令遵循能力有要求，需要更鲁棒的解析与自愈（见 parse_output）。
（这个取舍正好对应架构题模块五，README 里有展开。）

协议：模型每一步只输出一个 JSON 对象，二选一：
  A) 需要调用工具：
     {"thought": "...", "action": {"tool": "<name>", "args": {...}}}
  B) 可以直接回答：
     {"thought": "...", "final_answer": "..."}
"""
import json


SYSTEM_TEMPLATE = """你是一个能够使用工具的智能助手 Agent。你通过"思考-行动-观察"的循环来完成任务。

# 可用工具
{tools_block}

# 输出格式（严格遵守）
你每次**只能输出一个 JSON 对象**，不要输出任何 JSON 以外的内容（不要加解释、不要加```代码块围栏）。
JSON 必须是以下两种之一：

1) 当你需要调用工具时：
{{"thought": "你的思考：为什么要调用这个工具", "action": {{"tool": "工具名", "args": {{参数对象}}}}}}

2) 当你已经可以给出最终答案时（工具结果已足够，或本就无需工具）：
{{"thought": "你的思考", "final_answer": "给用户的最终回答"}}

# 规则
- args 必须符合对应工具的参数 schema。
- 一次只调用一个工具；拿到 observation 后再决定下一步。
- 简单的闲聊/常识问题可以直接 final_answer，不必调用工具。
- 需要精确计算用 calculator，不要自己心算；需要事实/时效信息用 search；记待办用 todo。
- 结合之前的对话历史与摘要来理解用户的追问。
"""


def _format_tools(schemas: list[dict]) -> str:
    blocks = []
    for s in schemas:
        params = json.dumps(s["parameters"], ensure_ascii=False)
        blocks.append(
            f"## {s['name']}\n描述: {s['description']}\n参数(JSON Schema): {params}"
        )
    return "\n\n".join(blocks)


def build_system_prompt(tool_schemas: list[dict], summary: str = "") -> str:
    prompt = SYSTEM_TEMPLATE.format(tools_block=_format_tools(tool_schemas))
    if summary:
        prompt += (
            "\n# 早期对话摘要（更久之前的内容已压缩为以下摘要，请据此保持连贯）\n"
            + summary
        )
    return prompt


# ----------------------------------------------------------------------------
# 输出解析
# ----------------------------------------------------------------------------
class ParseError(Exception):
    pass


def _extract_json(text: str) -> str:
    """从模型输出里抽出第一个平衡的 JSON 对象（容忍前后多余文字/代码围栏）。"""
    text = text.strip()
    # 去掉 ```json ... ``` 围栏
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
        text = text.strip()

    start = text.find("{")
    if start == -1:
        raise ParseError("输出中未找到 JSON 对象")

    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        c = text[i]
        if in_str:
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
        else:
            if c == '"':
                in_str = True
            elif c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
                if depth == 0:
                    return text[start:i + 1]
    raise ParseError("JSON 括号不平衡")


def parse_output(text: str) -> dict:
    """
    返回规范化结构之一：
      {"type": "action", "thought": str, "tool": str, "args": dict}
      {"type": "final",  "thought": str, "answer": str}
    解析失败抛 ParseError（上层会把错误作为 observation 反馈给模型让其自愈）。
    """
    raw = _extract_json(text)
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError as e:
        raise ParseError(f"JSON 解析失败: {e}")

    if not isinstance(obj, dict):
        raise ParseError("顶层不是 JSON 对象")

    thought = obj.get("thought", "")

    if "action" in obj and obj["action"]:
        action = obj["action"]
        if not isinstance(action, dict) or "tool" not in action:
            raise ParseError("action 缺少 tool 字段")
        return {
            "type": "action",
            "thought": thought,
            "tool": action["tool"],
            "args": action.get("args", {}) or {},
        }

    if "final_answer" in obj:
        return {"type": "final", "thought": thought, "answer": str(obj["final_answer"])}

    raise ParseError("JSON 中既无 action 也无 final_answer")
