"""
测试用例（离线、确定性，用 ScriptedLLM，不消耗真实 API）。

覆盖需求点：
  - 基本循环：判断直接回复 vs 调用工具
  - 三类工具：calculator / search(mock) / weather(mock) + todo
  - 纯对话追问 & 带工具的追问
  - session 隔离（两个窗口互不影响）
  - 工具报错自愈（异常作为 observation 反馈，模型换招）
  - LLM 输出解析失败自愈
  - context 压缩后仍能连贯回答（记忆召回）
  - 最大步数兜底

运行： python tests/test_agent.py
"""
import os
import sys
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from llm import ScriptedLLM
from tools import build_default_registry
from session import SessionManager
from agent import Agent, MAX_STEPS


def jdump(obj):
    return json.dumps(obj, ensure_ascii=False)


def make_agent(llm):
    return Agent(llm, build_default_registry())


# --- 通用 Driver：观察到工具结果就 finalize（回显结果），否则按队列出下一步 ---
class Driver:
    """
    队列元素二选一：
      {"tool": ..., "args": ...}  -> 输出一次工具调用
      {"final": "..."}            -> 直接给最终答案（用于纯对话）
    收到 observation（"工具返回：..."）时自动 finalize，回显结果，便于断言。
    """
    def __init__(self, queue):
        self.queue = list(queue)

    def __call__(self, messages):
        last = messages[-1]
        if last["role"] == "user" and last["content"].startswith("工具返回："):
            obs = last["content"][len("工具返回："):]
            return jdump({"thought": "已拿到工具结果", "final_answer": "结果：" + obs})
        item = self.queue.pop(0)
        if "final" in item:
            return jdump({"thought": "无需工具，直接回答", "final_answer": item["final"]})
        return jdump({"thought": "需要调用工具", "action": {"tool": item["tool"], "args": item["args"]}})


PASSED, FAILED = 0, 0


def check(name, cond, extra=""):
    global PASSED, FAILED
    if cond:
        PASSED += 1
        print(f"  PASS: {name}")
    else:
        FAILED += 1
        print(f"  FAIL: {name}  {extra}")


# ----------------------------------------------------------------------------
def test_calculator():
    print("\n[test] calculator 工具调用")
    llm = ScriptedLLM(fn=Driver([{"tool": "calculator", "args": {"expression": "128*7+30"}}]))
    mgr = SessionManager(to_console=False)
    ag = make_agent(llm)
    s = mgr.get_or_create("c1")
    ans = ag.chat(s, "算一下 128*7+30")
    check("答案含正确计算结果 926", "926" in ans, ans)
    check("历史里出现了 observation", any(m["role"] == "observation" for m in s.messages))


def test_direct_answer():
    print("\n[test] 纯对话（无需工具）")
    llm = ScriptedLLM(fn=Driver([{"final": "你好！有什么可以帮你的吗？"}]))
    mgr = SessionManager(to_console=False)
    ag = make_agent(llm)
    s = mgr.get_or_create("d1")
    ans = ag.chat(s, "你好")
    check("直接回答，无工具调用", not any(m["role"] == "observation" for m in s.messages), ans)
    check("答案非空", len(ans) > 0)


def test_search_and_weather():
    print("\n[test] search(mock) 与 weather(mock)")
    mgr = SessionManager(to_console=False)

    llm1 = ScriptedLLM(fn=Driver([{"tool": "search", "args": {"query": "ReAct"}}]))
    s1 = mgr.get_or_create("s1")
    ans1 = make_agent(llm1).chat(s1, "搜一下 ReAct 是什么")
    check("search 返回被带回答案", "ReAct" in ans1, ans1)

    llm2 = ScriptedLLM(fn=Driver([{"tool": "weather", "args": {"city": "北京"}}]))
    s2 = mgr.get_or_create("s2")
    ans2 = make_agent(llm2).chat(s2, "北京天气怎么样")
    check("weather 返回被带回答案", "北京" in ans2 and "℃" in ans2, ans2)


def test_session_isolation():
    print("\n[test] session 隔离（两个窗口待办互不影响）")
    mgr = SessionManager(to_console=False)

    llm_a = ScriptedLLM(fn=Driver([{"tool": "todo", "args": {"action": "add", "content": "带伞"}}]))
    sa = mgr.get_or_create("win1", user_id="A")
    make_agent(llm_a).chat(sa, "把'带伞'加到待办")

    llm_b = ScriptedLLM(fn=Driver([{"tool": "todo", "args": {"action": "add", "content": "周五提交周报"}}]))
    sb = mgr.get_or_create("win2", user_id="A")
    make_agent(llm_b).chat(sb, "把'周五提交周报'加到待办")

    # 回窗口1 列出待办
    llm_a2 = ScriptedLLM(fn=Driver([{"tool": "todo", "args": {"action": "list"}}]))
    ans = make_agent(llm_a2).chat(sa, "我的待办有哪些")

    check("win1 只含自己的待办", "带伞" in ans and "周报" not in ans, ans)
    check("win1 底层 todos 隔离", [t["content"] for t in sa.todos] == ["带伞"])
    check("win2 底层 todos 隔离", [t["content"] for t in sb.todos] == ["周五提交周报"])


def test_followup_with_memory():
    print("\n[test] 追问（记住上一轮工具结果）")
    mgr = SessionManager(to_console=False)
    s = mgr.get_or_create("f1")

    # 第一轮：查北京天气
    llm1 = ScriptedLLM(fn=Driver([{"tool": "weather", "args": {"city": "北京"}}]))
    make_agent(llm1).chat(s, "北京天气怎么样")

    # 第二轮：纯对话追问，模型应能从历史里引用上一轮的天气
    # 这里用一个能读历史的 fn：把历史里出现过的“℃”那条 observation 拿来回答
    def fn2(messages):
        prior = " ".join(m["content"] for m in messages)
        has_beijing_weather = "北京" in prior and "℃" in prior
        return jdump({"thought": "从历史回忆", "final_answer": ("刚才北京的天气在上文已给出" if has_beijing_weather else "我不记得了")})
    ans = make_agent(ScriptedLLM(fn=fn2)).chat(s, "那你还记得刚才北京的天气吗")
    check("追问能利用历史上下文", "已给出" in ans, ans)


def test_tool_error_self_heal():
    print("\n[test] 工具报错自愈（先给非法参数，再纠正）")
    mgr = SessionManager(to_console=False)
    s = mgr.get_or_create("e1")

    # 该 fn 逻辑：
    #  - 没有 observation：先犯错（todo done index=99，越界）
    #  - observation 含 ERROR：改用合法操作（add）
    #  - observation 不含 ERROR：finalize
    def fn(messages):
        last = messages[-1]
        is_obs = last["role"] == "user" and last["content"].startswith("工具返回：")
        if not is_obs:
            return jdump({"thought": "先试试完成第99条", "action": {"tool": "todo", "args": {"action": "done", "index": 99}}})
        obs = last["content"]
        if "ERROR" in obs:
            return jdump({"thought": "越界了，改为添加一条待办", "action": {"tool": "todo", "args": {"action": "add", "content": "买牛奶"}}})
        return jdump({"thought": "成功", "final_answer": "已处理：" + obs[len('工具返回：'):]})

    ans = make_agent(ScriptedLLM(fn=fn)).chat(s, "帮我处理待办")
    check("最终成功恢复", "买牛奶" in ans or "已添加" in ans, ans)
    check("历史里记录了 ERROR observation", any("ERROR" in m["content"] for m in s.messages if m["role"] == "observation"))


def test_parse_failure_self_heal():
    print("\n[test] 解析失败自愈（先输出垃圾，再合法）")
    mgr = SessionManager(to_console=False)
    s = mgr.get_or_create("p1")
    # 第一次返回非 JSON 垃圾，第二次返回合法 final
    llm = ScriptedLLM(responses=[
        "这不是 JSON，只是一段闲话。",
        jdump({"thought": "改正", "final_answer": "已按协议回答"}),
    ])
    ans = make_agent(llm).chat(s, "随便说点什么")
    check("解析失败后成功自愈", ans == "已按协议回答", ans)


def test_compression():
    print("\n[test] context 压缩 + 压缩后仍连贯")
    mgr = SessionManager(to_console=False)
    s = mgr.get_or_create("z1")

    # 人为塞入大量历史，超过压缩阈值；其中埋一个关键事实
    s.add("user", "我的项目代号是 Falcon。")
    s.add("assistant", jdump({"thought": "记下", "final_answer": "好的，记住了你的项目代号 Falcon。"}))
    for i in range(30):
        s.add("user", "闲聊内容 " + "填充" * 20 + str(i))
        s.add("assistant", jdump({"thought": "回应", "final_answer": "收到 " + "回复" * 20 + str(i)}))

    # 压缩器：当 system 提示是“对话压缩器”时，返回一段包含关键事实的摘要；
    # 否则作为普通助手，若历史/摘要里有 Falcon 就答对。
    def fn(messages):
        sys_txt = messages[0]["content"]
        if "对话压缩器" in sys_txt:
            return "用户的项目代号是 Falcon；其余为闲聊填充内容。"
        prior = " ".join(m["content"] for m in messages)
        if "Falcon" in prior:
            return jdump({"thought": "从摘要回忆", "final_answer": "你的项目代号是 Falcon。"})
        return jdump({"thought": "不记得", "final_answer": "我不记得了。"})

    size_before = s.approx_size()
    ans = make_agent(ScriptedLLM(fn=fn)).chat(s, "我的项目代号是什么？")
    check("发生了压缩（生成摘要）", s.summary != "", s.summary)
    check("压缩后历史规模下降", s.approx_size() < size_before)
    check("压缩后仍能答对关键事实", "Falcon" in ans, ans)


def test_max_steps():
    print("\n[test] 最大步数兜底（防死循环）")
    mgr = SessionManager(to_console=False)
    s = mgr.get_or_create("m1")
    # 永远调用工具、从不 finalize -> 应触发 MAX_STEPS 兜底
    def fn(messages):
        return jdump({"thought": "继续", "action": {"tool": "search", "args": {"query": "loop"}}})
    ans = make_agent(ScriptedLLM(fn=fn)).chat(s, "无限循环测试")
    check("触发兜底而非崩溃", "复杂" in ans or "拆细" in ans, ans)


if __name__ == "__main__":
    test_calculator()
    test_direct_answer()
    test_search_and_weather()
    test_session_isolation()
    test_followup_with_memory()
    test_tool_error_self_heal()
    test_parse_failure_self_heal()
    test_compression()
    test_max_steps()
    print(f"\n==== 测试结果: {PASSED} passed, {FAILED} failed ====")
    sys.exit(1 if FAILED else 0)
