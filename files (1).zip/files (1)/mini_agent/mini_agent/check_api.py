"""
check_api.py — 先单独验证 API Key / 网络 / 模型是否可用，再跑整套 Agent。

用法：
    export SILICONFLOW_API_KEY=sk-xxxx     # 或写进 .env
    python check_api.py                    # 用默认/环境变量里的模型
    python check_api.py Qwen/Qwen2.5-7B-Instruct   # 指定模型（免费小模型，适合先跑通）
"""
import os
import sys

# 复用 main.py 里的极简 .env 读取
def _load_dotenv():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(path):
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def main():
    _load_dotenv()
    model = sys.argv[1] if len(sys.argv) > 1 else os.getenv("MINI_AGENT_MODEL", "Qwen/Qwen2.5-72B-Instruct")

    from llm import SiliconFlowLLM, LLMError
    try:
        llm = SiliconFlowLLM(model=model)
    except LLMError as e:
        print("✗ 配置错误:", e)
        print("  请先设置 SILICONFLOW_API_KEY（环境变量或 .env）")
        sys.exit(1)

    print(f"→ 正在用模型 [{model}] 测试连通性 ...")
    try:
        reply = llm.complete([
            {"role": "system", "content": "只回复一个词。"},
            {"role": "user", "content": "请回复：pong"},
        ])
        print("✓ 连通成功，模型返回：", repr(reply.strip()))
        print("  现在可以运行： python main.py  或  python main.py --demo")
    except LLMError as e:
        print("✗ 调用失败:", e)
        print("  排查：1) key 是否正确/有余额 2) 模型名是否有效 3) 网络能否访问 api.siliconflow.cn")
        sys.exit(1)


if __name__ == "__main__":
    main()
