"""
trace.py — 工具调用与 Agent 执行轨迹记录

每个 session 拥有一个独立的 Trace。它同时做两件事：
1. 实时打印到终端（方便录屏演示每一步的 thought / action / observation）
2. 落盘到 logs/<session_id>.log，方便事后回看

设计要点：Agent 主循环的每一步都必须留痕，这样"模型为什么调这个工具/为什么这样回答"
是可复现、可审计的，而不是黑盒。
"""
import os
import json
import time
from datetime import datetime

LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")

# 终端颜色（不支持颜色的环境会显示原始字符，无副作用）
_COLORS = {
    "USER": "\033[96m",       # 青
    "THOUGHT": "\033[93m",    # 黄
    "ACTION": "\033[95m",     # 紫
    "OBSERVATION": "\033[94m",# 蓝
    "FINAL": "\033[92m",      # 绿
    "ERROR": "\033[91m",      # 红
    "SYSTEM": "\033[90m",     # 灰
}
_RESET = "\033[0m"


class Trace:
    def __init__(self, session_id: str, to_console: bool = True, to_file: bool = True):
        self.session_id = session_id
        self.to_console = to_console
        self.to_file = to_file
        self.events = []  # 内存中保留全部事件，便于测试断言
        if self.to_file:
            os.makedirs(LOG_DIR, exist_ok=True)
            self._path = os.path.join(LOG_DIR, f"{session_id}.log")
        else:
            self._path = None

    def log(self, kind: str, payload):
        """kind ∈ {USER, THOUGHT, ACTION, OBSERVATION, FINAL, ERROR, SYSTEM}"""
        event = {
            "ts": datetime.now().isoformat(timespec="seconds"),
            "session": self.session_id,
            "kind": kind,
            "payload": payload,
        }
        self.events.append(event)

        if isinstance(payload, (dict, list)):
            text = json.dumps(payload, ensure_ascii=False)
        else:
            text = str(payload)

        line = f"[{event['ts']}][{self.session_id}][{kind}] {text}"

        if self.to_console:
            color = _COLORS.get(kind, "")
            print(f"{color}{line}{_RESET}")

        if self._path:
            with open(self._path, "a", encoding="utf-8") as f:
                f.write(line + "\n")

    # 一些语义化的快捷方法
    def user(self, text):        self.log("USER", text)
    def thought(self, text):     self.log("THOUGHT", text)
    def action(self, tool, args):self.log("ACTION", {"tool": tool, "args": args})
    def observation(self, text): self.log("OBSERVATION", text)
    def final(self, text):       self.log("FINAL", text)
    def error(self, text):       self.log("ERROR", text)
    def system(self, text):      self.log("SYSTEM", text)
