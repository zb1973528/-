"""
agent.py — Agent Runtime（主循环）

一次 chat 的流程：
  1. 收到用户输入 -> 入历史
  2. 若历史过长 -> 先压缩（记忆召回：摘要注入 system）
  3. 进入 think-act-observe 循环（最多 MAX_STEPS 步）：
       - 组装 context -> 调 LLM -> 解析输出
       - 解析失败：把错误当 observation 反馈，让模型自愈（有独立重试预算）
       - action：执行工具（异常也转成 observation 反馈），继续循环
       - final：写回历史，返回给用户
  4. 超过最大步数：兜底返回，避免死循环

异常处理贯穿全程：工具报错、解析失败、LLM 失败都不崩溃，要么自愈要么优雅兜底。
"""
import json

from protocol import build_system_prompt, parse_output, ParseError
from context import build_messages, maybe_compress, clip_observation

MAX_STEPS = 8           # 单轮对话内最多的工具调用步数（防死循环/失控）
MAX_PARSE_RETRIES = 2   # 解析失败时，允许模型自愈的额外次数


class Agent:
    def __init__(self, llm, registry):
        self.llm = llm
        self.registry = registry

    def chat(self, session, user_input: str) -> str:
        session.trace.user(user_input)
        session.add("user", user_input)

        # 记忆召回时机①：每轮开始检查是否需要把旧历史压成摘要
        maybe_compress(session, self.llm)

        parse_retries = 0
        seen_calls: dict[str, str] = {}  # 本轮已执行过的 (工具+参数) -> 结果，用于去重
        for step in range(MAX_STEPS):
            system_prompt = build_system_prompt(self.registry.schemas(), session.summary)
            messages = build_messages(session, system_prompt)

            # --- 调 LLM（失败优雅兜底）---
            try:
                raw = self.llm.complete(messages)
            except Exception as e:
                session.trace.error(f"LLM 调用异常: {e}")
                fallback = "抱歉，我暂时无法连接到模型服务，请稍后再试。"
                session.add("assistant", fallback)
                return fallback

            # --- 解析输出 ---
            try:
                parsed = parse_output(raw)
            except ParseError as e:
                session.trace.error(f"解析失败: {e} | 原始输出: {raw[:200]}")
                if parse_retries < MAX_PARSE_RETRIES:
                    parse_retries += 1
                    # 把错误作为 observation 反馈，引导模型重新按协议输出（自愈）
                    session.add(
                        "observation",
                        f"你上一次的输出不是合法的协议 JSON（{e}）。"
                        f"请严格只输出一个符合协议的 JSON 对象，不要有多余内容。",
                    )
                    continue
                fallback = "抱歉，我没能正确组织这次回答，请换个说法再问一次。"
                session.add("assistant", fallback)
                return fallback

            # 记录思考过程
            if parsed["thought"]:
                session.trace.thought(parsed["thought"])
            # 模型这一步的原始输出入历史（保留 thought+action/final 供后续追问参考）
            session.add("assistant", raw)

            # --- 最终答案：结束循环 ---
            if parsed["type"] == "final":
                session.trace.final(parsed["answer"])
                return parsed["answer"]

            # --- 工具调用 ---
            tool_name = parsed["tool"]
            args = parsed["args"]
            session.trace.action(tool_name, args)

            tool = self.registry.get(tool_name)
            # 去重：同一轮内用相同参数重复调用同一工具是常见的 agent 反模式（会空转、绕圈）。
            # 命中则不再真跑，直接把"结果不会变"反馈回去，逼模型换参数/换工具或直接作答。
            call_key = tool_name + "|" + json.dumps(args, sort_keys=True, ensure_ascii=False)
            if call_key in seen_calls:
                obs = (
                    f"（已跳过重复调用）你本轮已用相同参数调用过 '{tool_name}'，结果不会变化：\n"
                    f"{seen_calls[call_key]}\n"
                    f"请不要重复相同调用；换一种参数/工具，或据现有信息直接给出最终答案。"
                )
                session.trace.system(f"检测到重复调用并跳过: {call_key}")
            elif tool is None:
                obs = f"ERROR: 不存在名为 '{tool_name}' 的工具。可用工具: {self.registry.names()}"
            else:
                try:
                    result = tool.run(args, session)
                    obs = clip_observation(result)
                    seen_calls[call_key] = obs  # 记录成功结果，供后续去重
                except Exception as e:
                    # 工具异常 -> 作为 observation 反馈，让模型换参数/换思路，而不是整体崩溃
                    obs = f"ERROR: 工具 '{tool_name}' 执行失败: {e}"

            session.trace.observation(obs)
            session.add("observation", obs)
            # 继续下一步循环，让模型基于 observation 决定继续调用还是给出答案

        # --- 超过最大步数兜底 ---
        session.trace.error(f"达到最大步数 {MAX_STEPS}，强制结束。")
        fallback = "这个任务比较复杂，我尝试了多步仍未完成，请把问题拆细一点再问我。"
        session.add("assistant", fallback)
        return fallback
