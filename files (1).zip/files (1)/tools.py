"""
tools.py — 工具抽象、注册表、以及具体工具实现

核心抽象：
- Tool：每个工具 = 名称 + 描述 + 参数 JSON Schema + run() 执行逻辑
- ToolRegistry：注册 / 查找 / 导出所有 schema（供 LLM 决策）

LLM 只看到 schema（名称、描述、参数），据此自主决定调用哪个工具、传什么参数。
run(args, session) 传入 session，是为了支持"会话级有状态工具"（如 todo：不同窗口
的待办互不影响）。
"""
import ast
import operator
import hashlib


# ----------------------------------------------------------------------------
# 基类 + 注册表
# ----------------------------------------------------------------------------
class Tool:
    name: str = ""
    description: str = ""
    parameters: dict = {}  # JSON Schema

    def run(self, args: dict, session) -> str:
        raise NotImplementedError

    def schema(self) -> dict:
        """导出给 LLM 的结构化描述。"""
        return {
            "name": self.name,
            "description": self.description,
            "parameters": self.parameters,
        }


class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool):
        if tool.name in self._tools:
            raise ValueError(f"工具重复注册: {tool.name}")
        self._tools[tool.name] = tool
        return tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return list(self._tools.keys())

    def schemas(self) -> list[dict]:
        return [t.schema() for t in self._tools.values()]


# ----------------------------------------------------------------------------
# 工具 1：calculator —— 安全的算术求值（用 ast，不用 eval，避免代码注入）
# ----------------------------------------------------------------------------
_ALLOWED_OPS = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
    ast.Pow: operator.pow, ast.USub: operator.neg, ast.UAdd: operator.pos,
}


def _safe_eval(node):
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)
    if isinstance(node, ast.Constant):  # 数字
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValueError("只支持数字常量")
    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_OPS:
        return _ALLOWED_OPS[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_OPS:
        return _ALLOWED_OPS[type(node.op)](_safe_eval(node.operand))
    raise ValueError("表达式包含不允许的运算")


class CalculatorTool(Tool):
    name = "calculator"
    description = "计算一个数学算术表达式，支持 + - * / // % ** 和括号。用于任何需要精确计算的场景。"
    parameters = {
        "type": "object",
        "properties": {
            "expression": {
                "type": "string",
                "description": "要计算的算术表达式，例如 '(3 + 4) * 2 ** 3'",
            }
        },
        "required": ["expression"],
    }

    def run(self, args, session) -> str:
        expr = args.get("expression", "")
        if not expr:
            raise ValueError("缺少参数 expression")
        tree = ast.parse(expr, mode="eval")
        result = _safe_eval(tree)
        return f"{expr} = {result}"


# ----------------------------------------------------------------------------
# 工具 2：search —— mock 搜索（离线可跑，结果确定性）
# ----------------------------------------------------------------------------
class SearchTool(Tool):
    name = "search"
    description = "在互联网上搜索信息，返回若干条相关结果的摘要。用于获取事实性/时效性信息。"
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "搜索关键词"},
        },
        "required": ["query"],
    }

    # 少量"命中"词条，让 demo 更真实；未命中则返回通用 mock 结果
    _CANNED = {
        "agent": "AI Agent 指能自主感知、决策、调用工具并执行多步任务的智能体，典型结构为 感知-规划-行动 循环。",
        "react": "ReAct 是一种让 LLM 交替进行推理(Reasoning)与行动(Acting)的范式，通过 Thought/Action/Observation 循环解决任务。",
        "硅基流动": "硅基流动(SiliconFlow)是一个提供 OpenAI 兼容 API 的大模型推理平台，支持 Qwen、DeepSeek、GLM 等模型。",
    }

    def run(self, args, session) -> str:
        query = (args.get("query") or "").strip()
        if not query:
            raise ValueError("缺少参数 query")
        for k, v in self._CANNED.items():
            if k.lower() in query.lower():
                return f"[搜索:{query}] {v}"
        # 通用 mock：返回 3 条确定性伪结果
        return (
            f"[搜索:{query}] 找到 3 条结果：\n"
            f"1. 关于「{query}」的概述性介绍。\n"
            f"2. 「{query}」的常见用法与示例。\n"
            f"3. 「{query}」相关的最新讨论（mock 数据）。"
        )


# ----------------------------------------------------------------------------
# 工具 3：weather —— mock 天气（确定性，基于城市名 hash）
# ----------------------------------------------------------------------------
class WeatherTool(Tool):
    name = "weather"
    description = "查询某个城市今天的天气（温度、天气状况）。"
    parameters = {
        "type": "object",
        "properties": {
            "city": {"type": "string", "description": "城市名，例如 '北京'"},
        },
        "required": ["city"],
    }

    _CONDS = ["晴", "多云", "小雨", "阴", "雷阵雨"]

    def run(self, args, session) -> str:
        city = (args.get("city") or "").strip()
        if not city:
            raise ValueError("缺少参数 city")
        h = int(hashlib.md5(city.encode("utf-8")).hexdigest(), 16)
        temp = 15 + (h % 20)          # 15~34 度
        cond = self._CONDS[h % len(self._CONDS)]
        return f"{city} 今天 {cond}，气温 {temp}℃（mock 数据）。"


# ----------------------------------------------------------------------------
# 工具 4：todo —— 会话级待办（有状态，存在 session 上，窗口之间互不影响）
# ----------------------------------------------------------------------------
class TodoTool(Tool):
    name = "todo"
    description = (
        "管理当前会话的待办事项。action=add 添加(需 content)；action=list 列出全部；"
        "action=done 完成(需 index，从 1 开始)。"
    )
    parameters = {
        "type": "object",
        "properties": {
            "action": {"type": "string", "enum": ["add", "list", "done"]},
            "content": {"type": "string", "description": "action=add 时的待办内容"},
            "index": {"type": "integer", "description": "action=done 时的序号(从1开始)"},
        },
        "required": ["action"],
    }

    def run(self, args, session) -> str:
        action = args.get("action")
        todos = session.todos  # 会话级存储：关键点在这里
        if action == "add":
            content = (args.get("content") or "").strip()
            if not content:
                raise ValueError("add 需要 content")
            todos.append({"content": content, "done": False})
            return f"已添加待办：{content}（当前共 {len(todos)} 条）"
        elif action == "list":
            if not todos:
                return "当前没有待办事项。"
            lines = [
                f"{i+1}. [{'x' if t['done'] else ' '}] {t['content']}"
                for i, t in enumerate(todos)
            ]
            return "当前待办：\n" + "\n".join(lines)
        elif action == "done":
            idx = args.get("index")
            if not isinstance(idx, int) or not (1 <= idx <= len(todos)):
                raise ValueError(f"index 非法，应为 1~{len(todos)}")
            todos[idx - 1]["done"] = True
            return f"已完成：{todos[idx-1]['content']}"
        else:
            raise ValueError(f"未知 action: {action}")


def build_default_registry() -> ToolRegistry:
    reg = ToolRegistry()
    reg.register(CalculatorTool())
    reg.register(SearchTool())
    reg.register(WeatherTool())
    reg.register(TodoTool())
    return reg
